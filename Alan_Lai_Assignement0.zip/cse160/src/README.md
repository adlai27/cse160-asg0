Alan Lai
adlai@ucsc.edu

Notes to Grader:
Referred to the vides provided, as well as ChatGPT